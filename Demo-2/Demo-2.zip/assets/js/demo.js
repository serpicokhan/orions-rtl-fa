$(function () {



$("#myform").on("submit","myform",function(){

alert("1");

});
});
