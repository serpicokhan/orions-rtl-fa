<?php
// Set connection variables
$db_host = "localhost";
$db_user = "ekadprin_root";
$db_pass = "84323267Man!@#";
$db_name = "ekadprin_ekad";

// Connect to the database
$con = mysqli_connect($db_host, $db_user, $db_pass, $db_name);
?>
