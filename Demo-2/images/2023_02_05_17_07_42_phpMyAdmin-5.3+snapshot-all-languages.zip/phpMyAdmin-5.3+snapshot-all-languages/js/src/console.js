import $ from 'jquery';
import { Console } from './modules/console.js';

$(function () {
    Console.initialize();
});

export { Console };
