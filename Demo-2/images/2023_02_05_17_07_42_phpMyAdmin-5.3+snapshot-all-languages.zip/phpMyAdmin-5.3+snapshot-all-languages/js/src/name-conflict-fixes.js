import $ from 'jquery';

$.widget.bridge('uiTooltip', $.ui.tooltip);
