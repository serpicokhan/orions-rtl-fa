<?php

declare(strict_types=1);

namespace PhpMyAdmin\Dbal;

use InvalidArgumentException;

class InvalidIdentifierName extends InvalidArgumentException
{
}
